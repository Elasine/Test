from bs4 import BeautifulSoup
import requests
import os

keyword = 'dog'
siteurl = 'https://www.hippopx.com/en/query?q=' + str(keyword)
header = {'User-Agent':'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 UBrowser/6.1.2107.204 Safari/537.36'}
url_get = requests.get(siteurl,headers=header)
# print(url_get.text)

url_soup = BeautifulSoup(url_get.content,'html.parser')
img_urls = url_soup.find('ul',id='flow').find_all('a',attrs={"itemprop":"url"})
# all_img = url_soup.find('ul',id='flow').find_all('img',attrs={"itemprop":"thumbnail"})

for img_url in img_urls:
    url = img_url.get('href')
    # print(url)
    url_get = requests.get(url,headers = header)
    url_soup = BeautifulSoup(url_get.text,'html.parser')
    page = url_soup.find(class_= 'pagi').find_all('a',id = 'next_page')
    # print(page)

    for p in range(1,int(len(page))):
        img_url = img_url.get('href') + '&page=' + str(p)
        img_url_get = requests.get(img_url,headers = header)
        img_url_soup = BeautifulSoup(img_url_get.text,'html.parser')
        img_url = img_url_soup.find('ul',id='flow').find_all('img',attrs={"itemprop":"thumbnail"})
        name = img_url[-9:]
        jpg = requests.get(img_url,headers = header)
        f = open(name,'wb')
        f.write(jpg.content)
        print(name + '.jpg saved')
        f.close()






# all_page = url_soup.find(class_='pagi').find_all('a',id = 'next_page')
# print(all_page)
# for img in all_img:
#     src = img.get('src')
#     for page in all_page:
#         max_img_page = page.get('href')[-1]
#         print(max_img_page)

