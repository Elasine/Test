# -*- coding: utf-8 -*-
import scrapy
from ..items import HippopxspiderItem
from ..  import settings
from scrapy.spiders import CrawlSpider,Rule
from scrapy.selector import Selector
from scrapy.http import Request

class HippopxSpider(scrapy.Spider):

    name = "hippopx"
    allowed_domains = ["hippopx.com"]
    def start_requests(self):
        keyword = "dog"
        for page in range(1,4):
            url = 'https://www.hippopx.com/en/query?q={}&page={}'.format(keyword,str(page))
            yield Request(url,callback=self.parse)

    def parse(self, response):
        print(response)
        hxs = Selector(response)
        imgs = hxs.xpath('//a/img/@src').extract()
        item = HippopxspiderItem()
        item['image_urls'] = imgs
        return item

















    # def parse(self, response):

    #     url_list = response.xpath('/html/body/main/ul/li[30]/figure/a/@href').extract()
    #     for url in url_list:
    #         item1 = HippopxspiderItem()
    #         item1["detailed"] = url
    #         item1["detailed"] = 'https://www.hippopx.com' + item1["detailed"]
    #         yield scrapy.Request(item1["detailed"],callback=self.parse_detail,
    #                              meta={"item":item1})
    #
    #     next_url = response.xpath('//*[@id="next_page"]/@href').extract_first()
    #     next_url = 'https://www.hippopx.com' + next_url
    #     if next_url:
    #         yield scrapy.Request(next_url, headers=settings.DEFAULT_REQUEST_HEADERS,
    #                              callback=self.parse)
    # def parse_detail(self,response):
    #     item1 = response.meta["item"]
    #     item1["image_urls"] = response.xpath("/html/body/main/ul/li[30]/figure/a/img/@src").extract()
    #     yield item1