# -*- coding:utf-8 -*-

import requests
import re
import os
from multiprocessing import pool

page_number = 40
urls = ['https://www.hippopx.com/en/query?q=dog&page={}'.format(str(page)) for page in range(1,page_number + 1)]
num = 0
for url in urls:
    img_url = requests.get(url).text
    res = re.compile(r'src="(http.+?jpg)"')
    reg = re.findall(res,img_url)


    for i in reg:
        print(i)
        a = requests.get(i)
        string = '%s' % num+ '.jpg'
        E = os.path.exists(string)
        if not E:
            f = open('%s.jpg'%num,'wb')
            f.write(a.content)
            f.close()
            num = num + 1
            print('第%s个图片下载完毕'%num)
        else:
            continue
