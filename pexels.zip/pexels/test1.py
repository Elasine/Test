# -*- coding:utf-8 -*-

import requests
import re

url = 'https://www.pexels.com/search/dog/'
img_url = requests.get(url).text
res = re.compile(r'data-pin-media="(https.+?jpeg)"')
reg = re.findall(res,img_url)

num = 0

for i in reg:
    print(i)
    a = requests.get(i)
    f = open('%s.jpeg'%num,'wb')
    f.write(a.content)
    f.close()
    num = num + 1
    print('第%s个图片下载完毕'%num)
