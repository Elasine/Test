# -*- coding: utf-8 -*-
import scrapy
from pexels.items import PexelsItem
from ..  import settings
from scrapy.spiders import CrawlSpider,Rule
from scrapy.selector import Selector
from scrapy.http import Request

class PexelsSpider(scrapy.Spider):

    name = "pexels"
    allowed_domains = ["pexels.com"]

    def start_requests(self):
        keyword = "dog"
        for page in range(1,3):
            url = 'https://www.pexels.com/search/{}/?page={}'.format(keyword,str(page))
            yield Request(url,callback=self.parse)

    def parse(self, response):
        print(response)
        hxs = Selector(response)
        imgs = hxs.xpath('//a/img/@data-pin-media').extract()
        item = PexelsItem()
        item['image_urls'] = imgs
        return item